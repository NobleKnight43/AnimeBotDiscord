# AnimeBot
Discord bot that uses the jikan api to pull anime/manga information from myanimelist
